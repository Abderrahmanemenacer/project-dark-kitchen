from flask import request, jsonify
from flask_jwt_extended import get_jwt_identity
from models import Kitchen, Item, Gallery, OrderItem, Order, User, KitchenReview,Category,order_status_type
from extensions import db
import uuid
from sqlalchemy.orm import joinedload
from flask_bcrypt import Bcrypt
from sqlalchemy import desc,func
import cloudinary
import random
from datetime import date

# Define allowed file types for image uploads
allowed_file_type = {"image/jpeg", "image/png", "image/jpg", "image/gif"}

bcrypt = Bcrypt()

def create_post():
    data = request.form
    user_id = get_jwt_identity()
    
    # Find user and ensure they are a kitchen
    user = User.query.get(user_id)
    if not user or user.role != "Seller":
        return jsonify({"error": "Unauthorized or user is not a kitchen"}), 403

    kitchen = Kitchen.query.filter_by(user_id=user_id).first()
    if not kitchen:
        return jsonify({"error": "Kitchen not found"}), 404

    try:
        item = Item(
            item_title=data["title"],
            item_description=data["description"],
            price=float(data["price"]),
            cat_id=data.get("category"),
            kitchen=kitchen,
            post_date=date.today(),
            aavailability=True  # This matches your model spelling
        )

        db.session.add(item)
        db.session.commit()

        images = request.files.getlist("images")
        for image in images:
            if image and image.filename and image.content_type in allowed_file_type:
                image_name = random.randint(100000, 999999)
                upload_result = cloudinary.uploader.upload(
                    image,
                    public_id=f"items/images/{image_name}",
                    overwrite=False
                )
                gallery = Gallery(
                    img_id=image_name,
                    image_link=upload_result["secure_url"],
                    item_id=item.item_id
                )
                db.session.add(gallery)

        db.session.commit()

        return jsonify({"creation": "successful",
                        "user_id": get_jwt_identity()})

    except Exception as e:
        db.session.rollback()
        return jsonify({"error": "Something went wrong", "details": str(e)}), 500

def update_post():
    
    user_id = get_jwt_identity()
    kitchen = Kitchen.query.filter_by(user_id=user_id).first()
    if not kitchen:
        return jsonify({"error": "Kitchen not found or unauthorized"}), 403

    if request.method == "GET":
        item_id = request.args.get("id")
        try:
            item_id = int(item_id)
        except (TypeError, ValueError):
            return jsonify({"error": "Invalid item ID"}), 400

        item = Item.query.get(item_id)
        if not item or item.kitchen_id != kitchen.kitchen_id:
            return jsonify({"error": "Item not found or not owned by you"}), 404

        return jsonify({
            "id": item.item_id,
            "title": item.item_title,
            "description": item.item_description,
            "price": item.price,
            "category": item.item_category.cat_name,
            "images": [
                {"image_id": image.img_id, "image_link": image.image_link}
                for image in item.gallery
            ]
        })

    else:
        data = request.form
        item = Item.query.get(data.get("id"))
        if not item or item.kitchen_id != kitchen.kitchen_id:
            return jsonify({"error": "Item not found or not owned by you"}), 404

        item.item_title = data.get("title")
        item.item_description = data.get("description")
        item.price = float(data.get("price", 0))
        item.cat_id = data.get("category")

        for url in request.form.getlist("deleteImages"):
            image = Gallery.query.filter_by(image_link=url).first()
            if image:
                cloudinary.uploader.destroy(str(image.img_id))
                db.session.delete(image)

        db.session.commit()

        new_images = request.files.getlist("newImages")
        for image in new_images:
            if image and image.filename and image.content_type in allowed_file_type:
                image_name = str(random.randint(100000, 999999))
                upload_result = cloudinary.uploader.upload(
                    image,
                    public_id=f"items/images/{image_name}",
                    overwrite=False
                )
                gallery = Gallery(
                    img_id=image_name,
                    image_link=upload_result["secure_url"],
                    item_id=item.item_id
                )
                db.session.add(gallery)

        db.session.commit()
        return jsonify({"updating": "successful"})

def delete_post():
    user_id = get_jwt_identity()
    kitchen = Kitchen.query.filter_by(user_id=user_id).first()
    if not kitchen:
        return jsonify({"error": "Unauthorized or kitchen not found"}), 403

    item_id = request.args.get("id")
    if not item_id:
        return jsonify({"error": "Item ID is required"}), 400

    item = Item.query.get(item_id)
    if not item or item.kitchen_id != kitchen.kitchen_id:
        return jsonify({"error": "Item not found or not owned by this kitchen"}), 404

    # Delete associated images from Cloudinary and DB
    for image in item.gallery:
        cloudinary.uploader.destroy(str(image.img_id))
        db.session.delete(image)

    # Delete the item itself
    db.session.delete(item)
    db.session.commit()

    return jsonify({"deletion": "successful"})

def upload_orders():
    per_page = request.args.get("per_page", default=10, type=int)
    page = request.args.get("page", default=1, type=int)
    status = request.args.get("status")

    user_id = get_jwt_identity()
    kitchen = Kitchen.query.filter_by(user_id=user_id).first()
    if not kitchen:
        return jsonify({"error": "Kitchen not found"}), 404

    # Base query: get distinct orders that include this kitchen's items
    query = (
        db.session.query(Order)
        .join(Order.order_items)
        .join(OrderItem.item)
        .filter(Item.kitchen_id == kitchen.kitchen_id)
        .options(
            joinedload(Order.order_items).joinedload(OrderItem.item),
            joinedload(Order.user)
        )
        .distinct()
    )

    if status:
        try:
            query = query.filter(Order.order_status == order_status_type(status))
        except ValueError:
            return jsonify({"error": "Invalid status"}), 400

    query = query.order_by(desc(Order.order_date))
    pagination = query.paginate(page=page, per_page=per_page, error_out=False)

    orders = []
    for order in pagination.items:
        # Find first item from this kitchen in the order
        item_data = next(
            (oi for oi in order.order_items if oi.item.kitchen_id == kitchen.kitchen_id),
            None
        )
        if not item_data:
            continue  # skip if no relevant item

        orders.append({
            "id": order.order_id,
            "customer": {
                "id": order.user.user_id,
                "name": order.user.full_name,
                "img": order.user.pfp
            },
            "item": {
                "id": item_data.item.item_id,
                "title": item_data.item.item_title,
                "quantity": item_data.quantity
            },
            "totalPrice": f"{int(item_data.quantity * item_data.price_at_order_time)} DA",
            "date": order.order_date.strftime("%b %d, %Y") if order.order_date else None,
            "status": order.order_status.name
        })

    return jsonify(orders)

def changing_status():
    # Authenticate and verify kitchen ownership
    user_id = get_jwt_identity()
    kitchen = Kitchen.query.filter_by(user_id=user_id).first()
    if not kitchen:
        return jsonify({"error": "Unauthorized"}), 403

    # Extract and validate inputs
    order_id = request.args.get("id")
    status_value = request.args.get("status")

    if not order_id or not status_value:
        return jsonify({"error": "Missing order ID or status"}), 400

    try:
        order_id = int(order_id)
    except ValueError:
        return jsonify({"error": "Invalid order ID"}), 400

    try:
        new_status = order_status_type(status_value)
    except ValueError:
        return jsonify({"error": "Invalid status value"}), 400

    order = Order.query.get(order_id)
    if not order:
        return jsonify({"error": "Order not found"}), 404

    # Verify this kitchen owns at least one item in the order
    is_kitchen_order = db.session.query(OrderItem).join(OrderItem.item).filter(
        OrderItem.order_id == order.order_id,
        Item.kitchen_id == kitchen.kitchen_id
    ).first()

    if not is_kitchen_order:
        return jsonify({"error": "You do not have permission to update this order"}), 403

    # Update status and commit
    order.order_status = new_status
    db.session.commit()

    return jsonify({"changing_status": "successful"})

def dashboard():
    user_id = get_jwt_identity()
    kitchen = Kitchen.query.filter_by(user_id=user_id).first()
    if not kitchen:
        return jsonify({"error": "Kitchen not found"}), 404

    # Latest 4 orders related to this kitchen
    latest_orders = (
        db.session.query(Order)
        .join(Order.order_items)
        .join(OrderItem.item)
        .filter(Item.kitchen_id == kitchen.kitchen_id)
        .options(
            joinedload(Order.order_items).joinedload(OrderItem.item),
            joinedload(Order.user)
        )
        .order_by(desc(Order.order_date))
        .distinct()
        .limit(4)
        .all()
    )

    orders = []
    for order in latest_orders:
        for order_item in order.order_items:
            if order_item.item.kitchen_id != kitchen.kitchen_id:
                continue
            orders.append({
                "id": order.order_id,
                "customer": {
                    "id": order.user.user_id,
                    "name": order.user.full_name,
                    "img": order.user.pfp
                },
                "item": {
                    "id": order_item.item_id,
                    "title": order_item.item.item_title,
                    "quantity": order_item.quantity
                },
                "totalPrice": f"{int(order_item.quantity * order_item.price_at_order_time)} DA",
                "date": order.order_date.strftime("%b %d, %Y") if order.order_date else None,
                "status": order.order_status.name  # no conversion
            })

    # Top 6 posts
    top_items = Item.query \
        .filter_by(kitchen_id=kitchen.kitchen_id) \
        .order_by(Item.avg_rating.desc()) \
        .limit(6).all()

    posts = [
        {
            "id": item.item_id,
            "img": item.gallery[0].image_link if item.gallery else None,
            "rating": item.avgrating(),
            "price": int(item.price),
            "title": item.item_title,
            "description": item.item_description
        }
        for item in top_items
    ]

    # Stats
    total_orders = db.session.query(func.count(func.distinct(Order.order_id))) \
        .join(Order.order_items) \
        .join(OrderItem.item) \
        .filter(Item.kitchen_id == kitchen.kitchen_id) \
        .scalar()

    total_dishes = Item.query.filter_by(kitchen_id=kitchen.kitchen_id).count()

    total_gains = db.session.query(func.coalesce(func.sum(OrderItem.quantity * OrderItem.price_at_order_time), 0.0)) \
        .join(OrderItem.item) \
        .filter(Item.kitchen_id == kitchen.kitchen_id) \
        .scalar()

    avg_rating = kitchen.avgrating()

    return jsonify({
        "id": kitchen.kitchen_id,
        "stats": {
            "totalOrders": total_orders,
            "totalDishes": total_dishes,
            "totalGains": int(total_gains),
            "averageRating": round(avg_rating, 1) if avg_rating else 0.0
        },
        "orders": orders,
        "posts": posts
    })

def get_customer_details():
    order_id = request.args.get("id", type=int)
    order = Order.query.filter_by(order_id=order_id).first()

    if not order:
        return jsonify({"error": "Order not found"}), 404

    # Assumption: each order contains exactly one order item
    if not order.order_items:
        return jsonify({"error": "No items found in the order"}), 404

    order_item = order.order_items[0]
    item = order_item.item
    user = order.user

    customer = {
        "id": user.user_id,
        "name": user.full_name,
        "profilePicture": user.pfp,
        "phoneNumbers": [pn.number for pn in user.phone_numbers],
        "adress": {
            "wilaya": user.address.wilaya,
            "baladiya": user.address.baladiya
        }
    }

    item_info = {
        "id": item.item_id,
        "title": item.item_title,
        "rating": item.avgrating(),
        "description": item.item_description,
        "image": item.gallery[0].image_link if item.gallery else None,
        "price": int(item.price)
    }

    return jsonify({
        "customer": customer,
        "orderItem": item_info,
        "notes": order_item.note
    })

def get_profile():
    user_id = get_jwt_identity()

    # Authenticated user's kitchen
    kitchen = Kitchen.query.filter_by(user_id=user_id).first()
    if not kitchen:
        return jsonify({"error": "Kitchen not found"}), 404

    user = kitchen.user
    address = user.address

    # Kitchen profile info
    kitchen_data = {
        "id": kitchen.kitchen_id,
        "name": kitchen.kitchen_name,
        "pfp": user.pfp,
        "cover": kitchen.cvp,
        "location": {
            "wilaya": address.wilaya,
            "baladiya": address.baladiya
        },
        "rating": round(kitchen.avgrating(), 1),
        "reviews": len(kitchen.reviews),
        "orders": sum(len(item.order_items) for item in kitchen.items),
        "description": kitchen.kitchen_bio,
        "phone_numbers": [
            {
                "id": phone.phone_num_id,
                "number": phone.number
            }
            for phone in user.phone_numbers
        ],
        "userName": user.full_name,
        "email": user.email
    }

    # Recent posts (limit 8)
    recent_items = Item.query.filter_by(kitchen_id=kitchen.kitchen_id).limit(8).all()

    items = [
        {
            "id": item.item_id,
            "title": item.item_title,
            "description": item.item_description,
            "image": item.gallery[0].image_link if item.gallery else None,
            "price": int(item.price),
            "avg_rating": round(item.avgrating(), 1),
            "category": item.item_category.cat_name if item.item_category else None
        }
        for item in recent_items
    ]

    return jsonify({
        "kitchenData": kitchen_data,
        "items": items
    })

def get_reviews():
    per_page = request.args.get("per_page", default=10, type=int)
    page = request.args.get("page", default=1, type=int)

    # Authenticate and get kitchen
    user_id = get_jwt_identity()
    kitchen = Kitchen.query.filter_by(user_id=user_id).first()
    if not kitchen:
        return jsonify({"error": "Kitchen not found"}), 404

    # Paginated query
    paginated_reviews = KitchenReview.query \
        .filter_by(kitchen_id=kitchen.kitchen_id) \
        .paginate(per_page=per_page, page=page, error_out=False)

    # Build reviews list
    reviews = [
        {
            "id": index + 1 + (paginated_reviews.page - 1) * paginated_reviews.per_page,
            "author": {
                "id": review.user.user_id,
                "name": review.user.full_name,
                "pfp": review.user.pfp
            },
            "rating": review.nbr_of_stars,
            "review": review.review_body
        }
        for index, review in enumerate(paginated_reviews.items)
    ]

    return jsonify({
        "kitchenId": kitchen.kitchen_id,
        "rating": round(kitchen.avgrating(), 1),
        "nbrreviews": len(kitchen.reviews),
        "reviews": reviews
    })

def update_kitchen_profile():
    user_id = get_jwt_identity()
    kitchen = Kitchen.query.filter_by(user_id=user_id).first()
    if not kitchen:
        return jsonify({"error": "Kitchen not found"}), 404

    user = kitchen.user

    # Update basic fields
    kitchen.kitchen_name = request.form.get("kitchenName", kitchen.kitchen_name)
    kitchen.kitchen_bio = request.form.get("kitchenBio", kitchen.kitchen_bio)
    user.full_name = request.form.get("fullName", user.full_name)
    user.email = request.form.get("email", user.email)

    # Update password if provided
    new_password = request.form.get("password")
    if new_password:
        user.password = bcrypt.generate_password_hash(new_password).decode("utf-8")

    # Update address fields if provided
    if "wilaya" in request.form:
        user.address.wilaya = request.form["wilaya"]
    if "baladiya" in request.form:
        user.address.baladiya = request.form["baladiya"]

    # Handle profile image upload
    profile_image = request.files.get("profileImage")
    if profile_image:
        upload_result = cloudinary.uploader.upload(
            profile_image,
            folder="users/pfp",
            overwrite=True
        )
        user.pfp = upload_result["secure_url"]

    # Handle cover image upload
    cover_image = request.files.get("coverImage")
    if cover_image:
        upload_result = cloudinary.uploader.upload(
            cover_image,
            folder="kitchens/cvp",
            overwrite=True
        )
        kitchen.cvp = upload_result["secure_url"]

    # Commit changes
    try:
        db.session.commit()
        return jsonify({"message": "Profile updated successfully"}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": "Failed to update profile", "details": str(e)}), 500

def get_paginated_items():
    page = request.args.get("page", default=1, type=int)
    per_page = request.args.get("per_page", default=10, type=int)

    # Get authenticated kitchen
    user_id = get_jwt_identity()
    kitchen = Kitchen.query.filter_by(user_id=user_id).first()
    if not kitchen:
        return jsonify({"error": "Kitchen not found"}), 404

    # Fetch paginated items
    pagination = Item.query \
        .filter_by(kitchen_id=kitchen.kitchen_id) \
        .options(joinedload(Item.gallery), joinedload(Item.item_category)) \
        .order_by(Item.post_date.desc()) \
        .paginate(page=page, per_page=per_page, error_out=False)

    # Format item list
    items = []
    for item in pagination.items:
        items.append({
            "id": item.item_id,
            "title": item.item_title,
            "description": item.item_description,
            "price": int(item.price),
            "avgRating": round(item.avgrating(), 1),
            "image": {
                "id": item.gallery[0].img_id,
                "url": item.gallery[0].image_link
            } if item.gallery else None,
            "category": item.item_category.cat_name if item.item_category else None
        })

    return jsonify({
        "items": items,
        "page": pagination.page,
        "perPage": pagination.per_page,
        "totalPages": pagination.pages,
        "totalItems": pagination.total,
        "hasNext": pagination.has_next,
        "hasPrev": pagination.has_prev
    })











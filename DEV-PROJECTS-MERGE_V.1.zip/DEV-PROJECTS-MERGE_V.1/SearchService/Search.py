from flask import jsonify, request
from sqlalchemy import or_
from models import Category, Item, Kitchen, Address , User
from flask import request

def search():
    filters = request.get_json()

    # Fallback to function arguments if not provided in filters
    page = int(request.args.get('page'))
    per_page = int(request.args.get('per_page'))  # ensure it's an int
    if not page :
        per_page = 8


    is_item = filters.get("Kitchen_or_Item") == "Item"
    search_term = filters.get("String")

    query = Item.query if is_item else Kitchen.query

    # Handle search term
    if search_term:
        if is_item:
            query = query.filter(
                or_(
                    Item.item_title.ilike(f"%{search_term}%"),
                    Item.item_description.ilike(f"%{search_term}%")
                )
            )
        else:
            query = query.filter(
                or_(
                    Kitchen.kitchen_name.ilike(f"%{search_term}%"),
                    Kitchen.kitchen_bio.ilike(f"%{search_term}%")
                )
            )

    # Filter by categories if it's an item
    if is_item and "categories" in filters:
        query = query.join(Item.item_category).filter(Category.cat_name == filters["categories"])

    # Join and filter by wilaya
    if "Willaya" in filters:
        if is_item:
            query = query.join(Item.kitchen).join(Kitchen.user).join(User.address).filter(Address.wilaya == filters["Willaya"])
        else:
            query = query.join(Kitchen.user).join(User.address).filter(Address.wilaya == filters["Willaya"])

    # Join and filter by baladiya
    if "Baladiya" in filters:
        if is_item:
            query = query.join(Item.kitchen).join(Kitchen.user).join(User.address).filter(Address.baladiya == filters["Baladiya"])
        else:
            query = query.join(Kitchen.user).join(User.address).filter(Address.baladiya == filters["Baladiya"])

    # Apply pagination
    pagination = query.paginate(page=page, per_page=per_page, error_out=False)
    results = pagination.items

    return jsonify({
        "total": pagination.total,
        "pages": pagination.pages,
        "current_page": pagination.page,
        "per_page": pagination.per_page,
        "results": [
            {
                "id": d.item_id if is_item else d.kitchen_id,
                "name": d.item_title if is_item else d.kitchen_name,
                "description": d.item_description if is_item else d.kitchen_bio,
                "categories": d.item_category.cat_name if is_item and d.item_category else None,
                "wilaya": d.kitchen.user.address.wilaya if is_item else d.user.address.wilaya,
                "baladiya": d.kitchen.user.address.baladiya if is_item else d.user.address.baladiya,
                "type": "Item" if is_item else "Kitchen"
            } for d in results
        ]
    })



"""


def Search_Service(Kitchen_or_Item, categories_name):
    


    # If the current user is not a client, redirect
    if user['role'] != 'Client':
        referrer = request.referrer
        if referrer and urlparse(referrer).netloc == request.host:
            return redirect(referrer)
        return redirect(url_for('home'))



    
    min_rating = request.args.get('min_rating', type=float)
    city_filter = request.args.get('city')
    sort = request.args.get('sort', default='rating_desc')
    
    if city_filter:
        query = query.filter_by(location_city=city_filter)

    # Filter by rating if provided
    if min_rating is not None:
        query = query.filter(ShopPost.rating >= min_rating)

    # Sorting
    if sort == 'rating_asc':
        query = query.order_by(ShopPost.rating.asc())
    else:
        query = query.order_by(ShopPost.rating.desc())


    rating = request.args.get('rating', type=float)
    search_term = request.args.get('search', '', type=str).strip()
    
    # Try to get page/per_page from query params first, then fall back to JSON body, then default
    try:
        page = request.args.get('page', type=int)
        per_page = request.args.get('per_page', type=int)

        if page is None or per_page is None:
            data = request.get_json(silent=True) or {}
            page = page or data.get('page', 1)
            per_page = per_page or data.get('per_page', 10)
        else:
            # If both came from query, still ensure defaults
            page = page or 1
            per_page = per_page or 10

    except:
        # If anything goes wrong (like malformed JSON), use defaults
        page = 1
        per_page = 10



    #edit it so it accept the categories
    # Item Search
    if Kitchen_or_Item == 'Item':
        if cate !='null' :
            cate = categories.query.filter_by(cat_name=categories_name).first()

        items_query = Item.query.filter(
            Item.categories == cate.cat_id
        )

        if rating is not None:
            items_query = items_query.filter(Item.avg_rating >= rating)

        if search_term:
            items_query = items_query.filter(Item.item_title.ilike(f'%{search_term}%'))


        paginated_items = items_query.paginate(page=page, per_page=per_page, error_out=False)

        return jsonify({
            'items': [{
                'Item_id': item.item_id,
                'title': item.item_title,
                'rating': item.avg_rating,
                'price': item.price,
                'Description': item.item_description
            } for item in paginated_items.items],
            'total': paginated_items.total,
            'pages': paginated_items.pages,
            'current_page': paginated_items.page
        })

    # Kitchen Search
    elif Kitchen_or_Item == 'kitchen':
        client = User.query.filter_by(user_id=user).first()
        if not client:
            return jsonify({'error': 'User not found'}), 404

        client_address_id = client.address_id

        kitchens_query = Kitchen.query.join(User).filter(
            User.address_id == client_address_id
        )

        if rating is not None:
            kitchens_query = kitchens_query.filter(Kitchen.avg_rating >= rating)

        if search_term:
            kitchens_query = kitchens_query.filter(Kitchen.kitchen_name.ilike(f'%{search_term}%'))


        paginated_kitchens = kitchens_query.paginate(page=page, per_page=per_page, error_out=False)

        return jsonify({
            'kitchens': [{
                'kitchen_id': k.kitchen_id,
                'kitchen_name': k.kitchen_name,
                'bio': k.kitchen_bio,
                'rating': k.avg_rating,
                'pfp': k.pfp
            } for k in paginated_kitchens.items],
            'total': paginated_kitchens.total,
            'pages': paginated_kitchens.pages,
            'current_page': paginated_kitchens.page
        })


    return jsonify({'error': 'Invalid type'}), 400
"""


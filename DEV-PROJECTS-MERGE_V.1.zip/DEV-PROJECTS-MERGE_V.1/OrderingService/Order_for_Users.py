import datetime  
#from Items_Services import get_avg_rating
from extensions import db
from urllib.parse import urlparse
from sqlalchemy.orm import joinedload
from flask import jsonify, request, url_for
from models import Category, Gallery, Item, KitchenReview, Order, OrderItem, order_status_type, User, CartItem, Cart
from flask_jwt_extended import  get_jwt_identity
from cloudinary.utils import cloudinary_url
from sqlalchemy.exc import SQLAlchemyError


def get_orders_associated_with_user():
    
    user_id = get_jwt_identity()
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 10, type=int)

    user = User.query.get(user_id)
    if not user:
        return jsonify({"message": "User not found"}), 404

    pagination = Order.query.filter_by(user_id=user_id) \
        .options(joinedload(Order.order_items)) \
        .paginate(page=page, per_page=per_page, error_out=False)

    orders = pagination.items

    orders_list = []
    for order in orders:
        for order_item in order.order_items:
            item = order_item.item
            kitchen = item.kitchen

            order_details = {
                "id": order.order_id,
                "kitchen": {
                    "kitchenId": kitchen.kitchen_id,
                    "name": kitchen.kitchen_name
                },
                "orderitems": {
                    "itemId": order_item.order_item_id,
                    "quantity": order_item.quantity,
                    "price": order_item.price_at_order_time,
                    "post": {
                        "id": item.item_id,
                        "title": item.item_title,
                        "img": Gallery.query.filter_by(item_id=item.item_id).first().image_link if item.gallery else None,
                        "description": item.item_description,
                        "category": Category.query.get(item.cat_id).cat_name if item.cat_id else None,
                        "rating": item.avg_rating
                    },
                },
                "date": getattr(order, 'order_date', None),
                "totalPrice": sum(i.price_at_order_time * i.quantity for i in order.order_items),
                "status": str(order.order_status)
            }
            orders_list.append(order_details)

    return jsonify({
        "orders": orders_list,
        "pagination": {
            "page": pagination.page,
            "per_page": pagination.per_page,
            "total": pagination.total,
            "pages": pagination.pages,
            "has_next": pagination.has_next,
            "has_prev": pagination.has_prev
        }
    })


"""ki

    },
    "orderitems": [
    ],
    "totalPrice": 7500,
    "date": "Jan 1, 2024",
    "status": "Pending"
  }"""



def get_order_details():
    user_id = get_jwt_identity()
    order_id = request.args.get('order_id')
    # Get the requested order (assuming one order → one order_item)
    order = Order.query.filter_by(order_id=order_id, user_id=user_id).first()

    if not order:
        return jsonify({"message": "Order not found"}), 404

    # We expect only one order_item
    order_item = order.order_items[0]
    item = order_item.item

    # Handle post_date and created_at
    post_date = item.post_date
    if isinstance(post_date, datetime.date) and not isinstance(post_date, datetime.datetime):
        post_date = datetime.datetime.combine(post_date, datetime.time.min, tzinfo=datetime.timezone.utc)

    now = datetime.datetime.now(datetime.timezone.utc)
    time_diff = now - post_date
    hours_diff = time_diff.total_seconds() // 3600
    created_at = f"{int(hours_diff)} hours ago" if hours_diff < 24 else post_date.strftime("%Y-%m-%d")

    # Prepare the response JSON
    items_details = [{
        "id": item.item_id,
        "orderitems": {
            "itemId": order_item.order_item_id,
            "quantity": order_item.quantity,
            "price": order_item.price_at_order_time,
            "post": {
                "id": item.item_id,
                "title": item.item_title,
                "img": Gallery.query.filter_by(item_id=item.item_id).first().image_link if item.gallery else None,
                "description": item.item_description,
                "category": Category.query.get(item.cat_id).cat_name if item.cat_id else None,
                "rating": item.avg_rating
            },
        },
        "note": order_item.note,
        "date": order.order_date,
        "totalPrice": order_item.price_at_order_time * order_item.quantity,
        "status":  order.order_status
    }]

    return jsonify({
        "details": getattr(order, 'Note', None),
        "items": items_details,
    })

"""{
  "id": 1,
  "orderItems": [
    {
      "price_at_order_time": 2300,
      "quantity": 2,
      "notes": "Extra spicy sauce",
      "post": {
        "id": 1,
        "category": "Pizza",
        "name": "Pizza Thon",
        "price": 2500,
        "img": "/static/images/indexpage/index3.jpg"
      }
    }
  ],
  "totalPrice": 7500,
  "notes": "Extra cheese, no olives",
  "date": "Jan 1, 2024",
  "status": "Pending"
}"""


"""

def place_order():
    data = request.get_json()

    cart_items = CartItem.query.join(Cart).filter(CartItem.cart_id == Cart.cart_id, Cart.user_id == data['user_id']).all()

    if not cart_items:
        return jsonify({"message": "Cart is empty"}), 400

    total_price = sum(item.item.price * item.quantity for item in cart_items)

    new_order = Order(
        user_id=data['user_id'],
        order_status=OrderStatusType.pending,
        total_price=total_price
    )
    db.session.add(new_order)
    db.session.flush()  # So new_order gets an ID before using it

    created_orders = []

    for cart_item in cart_items:
        item = cart_item.item
        quantity = cart_item.quantity

        #  socketio.emit('new_order', data, room=f'kitchen_{kitchen_id}')

        order_item = OrderItem(
            order_id=new_order.order_id,
            item_id=item.item_id,
            quantity=quantity,
            price_at_order_time=item.price,
            status='PENDING'
        )

        db.session.add(order_item)
        created_orders.append({
            "item": item.name,
            "quantity": quantity,
            "price": item.price
        })

    # Delete all cart items
    CartItem.query.filter_by(cart_id=data['cart_id']).delete()

    db.session.commit()

    return jsonify({"message": "Order placed successfully", "order_id": new_order.order_id}), 201
"""

def place_order():
    user_id = get_jwt_identity()

    if not user_id:
        return jsonify({"message": "User not authenticated"}), 401

    try:
        cart = Cart.query.filter_by(user_id=user_id).first()
        if not cart:
            return jsonify({"message": "Cart not found for this user"}), 404

        cart_items = CartItem.query.filter_by(cart_id=cart.cart_id).all()
        if not cart_items:
            return jsonify({"message": "Cart is empty"}), 400


        orders_list = []

        for cart_item in cart_items:
            if not cart_item.item:
                return jsonify({"message": f"Item with ID {cart_item.item_id} not found"}), 400


            total_price = cart_item.item.price * cart_item.quantity

            new_order = Order(
                user_id=user_id,
                order_status=order_status_type.pending,
                total_price=total_price
            )
            db.session.add(new_order)
            db.session.flush()  # assign order_id

            order_item = OrderItem(
                order_id=new_order.order_id,
                item_id=cart_item.item_id,
                quantity=cart_item.quantity,
                price_at_order_time=cart_item.item.price,
            )

            db.session.add(order_item)

            order_list = {
                "message": "Order placed successfully",
                "order_id": new_order.order_id,
                "total_price": total_price,
                "status_order" : new_order.order_status.value,
            } 
            orders_list.append(order_list)

        # Delete cart items - using ORM delete for cascade and events might be better
        CartItem.query.filter_by(cart_id=cart.cart_id).delete()

        db.session.commit()

        return jsonify(orders_list), 201

    except SQLAlchemyError as e:
        db.session.rollback()
        return jsonify({"message": "Database error", "error": str(e)}), 500
    except Exception as e:
        return jsonify({"message": "Unexpected error", "error": str(e)}), 500

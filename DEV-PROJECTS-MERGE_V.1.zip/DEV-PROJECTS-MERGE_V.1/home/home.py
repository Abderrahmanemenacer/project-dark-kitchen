from extensions import bcrypt
from datetime import datetime
from flask import jsonify, request
from flask_jwt_extended import get_jwt_identity, jwt_required
from sqlalchemy import desc
from models import Ad, Address, Item, ItemReview, Kitchen, KitchenReview, User, UserPhoneNumber
from extensions import db
import cloudinary.uploader
import cloudinary.utils


def get_postById(post_id):
    post = Item.query.get_or_404(post_id)
    kitchen = post.kitchen
    reviews = ItemReview.query.filter_by(item_id=post_id).all()
    category = post.item_category


    full_post = {
        "id": post.item_id,
        "title": post.item_title,
        "description": post.item_description,
        "price": post.price,
        "orders" : len(post.order_items) if post.order_items else 0,
        "images":  [
            image.image_link for image in post.gallery] if post.gallery else [],
        "category": {
            "id": category.cat_id,
            "name": category.cat_name
        },
        "delay": f"{(datetime.now().date() - post.post_date).days} days ago",
        "rating": {
            "value": post.avgrating(),
            "count": len(reviews)
        },
        "kitchen": {
            "id": kitchen.kitchen_id,
            "name": kitchen.kitchen_name,
            "pfp": kitchen.user.pfp,
            "rating": {
                "value":  kitchen.avgrating(),
                "count": sum([len(item.reviews) for item in kitchen.items])
            },
            "location": {
                "wilaya": kitchen.user.address.wilaya ,
                "baladiya": kitchen.user.address.baladiya
            },
            "is_in_favorites": post in User.query.get(get_jwt_identity()).favorites if get_jwt_identity() else False
        }
    }
    return jsonify({"full_post": full_post}), 200

def recommend_of_item(post_id):
    # Get the original post/item
    post = Item.query.get_or_404(post_id)
    category = post.item_category

    # Filter other items in the same category, excluding the current item
    postrecomnds = Item.query.filter(
        Item.item_category == category,
        Item.item_id != post.item_id  # Exclude the original item
    ).limit(10).all()

    # Format the response
    recommended_dishes = [
        {
            "item_id": postrecomnd.item_id,
            "title": postrecomnd.item_title,
            "chef": {
                "name": postrecomnd.kitchen.user.full_name, 
                "kitchen_id": postrecomnd.kitchen.kitchen_id,
                "profile_picture": postrecomnd.kitchen.user.pfp,
                "location": {
                    "wilaya": postrecomnd.kitchen.user.address.wilaya,
                    "baladiya": postrecomnd.kitchen.user.address.baladiya
                }
            },
            "description": postrecomnd.item_description,
            "price": postrecomnd.price,
            "image_url": postrecomnd.gallery[0].image_link if postrecomnd.gallery else None,
            "category": {
                "id": postrecomnd.item_category.cat_id,
                "name": postrecomnd.item_category.cat_name
            },
            "rating": {
                "value": postrecomnd.avgrating(),
                "count": len(postrecomnd.reviews)
            },
            "delay": f"{(datetime.now().date() - postrecomnd.post_date).days} days ago",
            "is_in_favorites": postrecomnd in User.query.get(get_jwt_identity()).favorites if get_jwt_identity() else False
        }
        for postrecomnd in postrecomnds
    ]

    return jsonify({"recommendedDishes": recommended_dishes})

#rev
def getMoreReviews (post_id):
    page = int(request.args.get('page', 1))
    per_page = int(request.args.get('per_page', 4))  
    pages_skip = (page - 1) * per_page #reviews-skip

    # Filter by order
    query = ItemReview.query.filter_by(item_id=post_id).order_by(desc(ItemReview.nbr_of_stars))

    total_reviews = query.count()
    item = Item.query.filter_by(item_id=post_id).first()
    avg_rating = item.avgrating() if item else 0
    reviews = query.offset(pages_skip).limit(per_page).all()#return it as a list
    reviews_data = [
        {
            "author": {
                "id_author": review.user.user_id,
                "name": review.user.full_name,
                "pfp": review.user.pfp 
            },
            "id_review": review.item_id,
            "rating": review.nbr_of_stars,
            "content": review.review_body
        }
        for review in reviews
    ]

    has_more = (pages_skip + per_page) < total_reviews

    return jsonify({
        "reviews": reviews_data,
        "has_more": has_more,
        "total_reviews": total_reviews,
        "avg_rating": avg_rating
    })

def get_popular_post():
    page = int(request.args.get('page', 1))
    per_page = int(request.args.get('per_page', 10))
    current_user = User.query.get(get_jwt_identity()) if get_jwt_identity() else None
    favorite_ids = {fav.item_id for fav in current_user.favorites} if current_user else set()



    items = Item.query.all()
    items_with_avg = [
        (item, item.avgrating()) for item in items if  item.avgrating() >= 4
    ]
    items_with_avg.sort(key=lambda x: x[1], reverse=True)

    start = (page - 1) * per_page
    end = start + per_page
    paginated_items = items_with_avg[start:end]

    result = []
    for item, avg in paginated_items:
        #image_url = item.gallery[0].image_link
        result.append({
            "item_id": item.item_id,
            "title": item.item_title,
            "description": item.item_description,
            "price": item.price,
            "average_rating": avg,
            "delay": f"{(datetime.now().date() - item.post_date).days} days ago",
            "image_url": item.gallery[0].image_link if item.gallery else None,
            "category": {
                "id": item.item_category.cat_id,
                "name": item.item_category.cat_name
            },
            "chef": {
                "name": item.kitchen.user.full_name,
                "kitchen_id": item.kitchen.kitchen_id,
                "profile_picture": item.kitchen.user.pfp,
                "location": {
                "wilaya": item.kitchen.user.address.wilaya,
                "baladiya": item.kitchen.user.address.baladiya
            }
            },
             "is_in_favorites": item.item_id in favorite_ids

            
        })

    return jsonify({
        "page": page,
        "per_page": per_page,
        "total_items": len(items_with_avg),
        "items": result,
        "has_more": (end < len(items_with_avg))
    })

def get_bestKitchens():
    page = int(request.args.get('page', 1))
    per_page = int(request.args.get('per_page', 10))

    kitchens = Kitchen.query.all()
    kitchens_with_avg = [
        {
            'kitchen_id': kitchen.kitchen_id,
            'kitchen_name': kitchen.kitchen_name,
            'avg_rating': kitchen.avg_rating,
            'location': {
                'wilaya': kitchen.user.address.wilaya if kitchen.user.address else None,
                'baladiya': kitchen.user.address.baladiya if kitchen.user.address else None
            },
            "kitchen profile" : kitchen.user.pfp
        }
        for kitchen in kitchens if kitchen.avgrating() > 4
    ]
    kitchens_with_avg.sort(key=lambda x: x['avg_rating'], reverse=True)

    start = (page - 1) * per_page
    end = start + per_page
    paginated_kitchens = kitchens_with_avg[start:end]

    return jsonify({
        'page': page,
        'per_page': per_page,
        'total_kitchens': len(kitchens_with_avg),
        'kitchens': paginated_kitchens,
        "has_more": (end < len(kitchens_with_avg))
    })



def get_items_by_user_location():
    user_id = get_jwt_identity()

    # 1. Get the user's address
    user = User.query.filter_by(user_id=user_id).first()
    if not user or not user.address:
        return jsonify({'error': 'User or user location not found'}), 404

    user_location = user.address
    wilaya = user_location.wilaya
    baladiya = user_location.baladiya

    # 2. Get users in the same location
    matching_users = User.query.join(Address).filter(
        Address.wilaya == wilaya,
        Address.baladiya == baladiya
    ).all()
    matching_user_ids = [u.user_id for u in matching_users]

    # 3. Get kitchens from those users
    kitchens = Kitchen.query.filter(Kitchen.user_id.in_(matching_user_ids)).all()
    kitchen_ids = [k.kitchen_id for k in kitchens]

    # 4. Get items from those kitchens
    items = Item.query.all()
    page = int(request.args.get('page', 1))
    per_page = int(request.args.get('per_page', 10))
    start = (page - 1) * per_page
    end = start + per_page
    paginated_items = items[start:end]
    current_user = User.query.get(get_jwt_identity()) if get_jwt_identity() else None
    favorite_ids = {fav.item_id for fav in current_user.favorites} if current_user else set()
    # 5. Format result
    result = []
    for item in paginated_items:
        result.append({
            'item_id': item.item_id,
            'title': item.item_title,
            'description': item.item_description,
            'price': item.price,
            'average_rating': item.avgrating(),
            'image_url' : item.gallery[0].image_link if item.gallery else None,
            'delay': f"{(datetime.now().date() - item.post_date).days} days ago",
            'category': {
                'id': item.item_category.cat_id,
                'name': item.item_category.cat_name
            },
            'chef': {
                'name': item.kitchen.user.full_name,
                'kitchen_id': item.kitchen.kitchen_id,
                'profile_picture': item.kitchen.user.pfp,
                'location': {
                'wilaya': item.kitchen.user.address.wilaya,
                'baladiya': item.kitchen.user.address.baladiya
            }
                
            },
            'is_in_favorites':   item.item_id in favorite_ids,
            "has_more": (end < len(items)),
            
        })

    return jsonify({'items': result}), 200


def write_reviews(item_id):
    user_id = get_jwt_identity()
    data = request.get_json()

    nbr_of_stars = data.get('nbr_of_stars')
    review_body = data.get('review_body')

    # Basic validation
    if nbr_of_stars is None or review_body is None:
        return jsonify({'error': 'Missing required fields'}), 400
    if float(nbr_of_stars) < 1 or float(nbr_of_stars) > 5:
        return jsonify({'error': 'Rating must be between 1 and 5'}), 400

    new_review = ItemReview(
        user_id=user_id,
        item_id=item_id,
        nbr_of_stars=nbr_of_stars,
        review_body=review_body
    )


    db.session.add(new_review)
    db.session.commit()


    return jsonify({'message': 'Review submitted successfully'}), 201




def edit_profile():
    user_id = get_jwt_identity()
    user = User.query.get(user_id)

    if not user:
        return jsonify({'error': 'User not found'}), 404

    # Get form fields
    full_name = request.form.get('full_name')
    email = request.form.get('email')
    password = request.form.get('password')
    wilaya = request.form.get('wilaya')
    baladiya = request.form.get('baladiya')

    # Update user basic info if provided
    if full_name:
        user.full_name = full_name
    if email:
        user.email = email
    if password and password.strip():
        user.password = bcrypt.generate_password_hash(password).decode()

    # Upload photo to Cloudinary (if provided)
    if 'photo' in request.files:
        photo = request.files['photo']
        if photo and photo.filename != '':
            try:
                # Upload to Cloudinary
                result = cloudinary.uploader.upload(photo)

                # Generate a standard URL (you can add width/height/crop here)
                url, _ = cloudinary.utils.cloudinary_url(result['public_id'])
                user.pfp = url

            except Exception as e:
                return jsonify({'error': f'Photo upload failed: {str(e)}'}), 500

    # Update address
    if wilaya or baladiya:
        if not user.address:
            user.address = Address(user=user)  # Make sure you set the relationship correctly
        if wilaya:
            user.address.wilaya = wilaya
        if baladiya:
            user.address.baladiya = baladiya

    db.session.commit()
    return jsonify({'message': 'Profile updated successfully'}), 200

def get_user_profile():
    user_id = get_jwt_identity()
    user = User.query.get(user_id)

    if not user:
        return jsonify({'error': 'User not found'}), 404
    profile_data = {
        'full_name': user.full_name,
        'email': user.email,
        'phone_number': [phone.number for phone in UserPhoneNumber.query.filter_by(user_id=user_id).all()],
        'address': f"{user.address.wilaya}, {user.address.baladiya}" if user.address and user.address.wilaya and user.address.baladiya else "",
        'profile_pic' : user.pfp ,
        'member_since':user.registration_date.strftime('%B %d, %Y'),
        'pfp': user.pfp
    }

    return jsonify(profile_data), 200



def get_ads():
    try:
        # Get all ads without pagination
        ads_query = Ad.query.order_by(desc(Ad.ads_id)).all()
        
        ad_list = [
            {
                'id': ad.ads_id,
                'image_url': ad.image_link,
                'kitchen_id': ad.kitchen_id,  # Direct access to kitchen_id
                'kitchen_name': ad.kitchen.kitchen_name if ad.kitchen else None  # Optional: include kitchen name
            } for ad in ads_query
        ]

        return jsonify({
            'ads': ad_list,
            'total_ads': len(ad_list)
        }), 200

    except Exception as e:
        return jsonify({'error': 'Failed to fetch ads', 'details': str(e)}), 500


def visit_kitchen(kitchen_id):
    kitchen = Kitchen.query.get_or_404(kitchen_id)
    full_kitchen = {
        "kitchen_id": kitchen.kitchen_id,
        "kitchen_name": kitchen.kitchen_name,
        "kitchen_bio": kitchen.kitchen_bio,
        "pfp": kitchen.user.pfp,
        "cvp": kitchen.cvp,
        "avg_rating": kitchen.avgrating(),
        "nbr_reviews": len(kitchen.reviews),
        "nbr_orders": sum(len(item.order_items) for item in kitchen.items),
        "kitchen_numbers": [phone.number for phone in kitchen.user.phone_numbers] if kitchen.user.phone_numbers else [],
        "location": {
            "wilaya": kitchen.user.address.wilaya,
            "baladiya": kitchen.user.address.baladiya
        }
    }
    return jsonify({"full_kitchen": full_kitchen}), 200


def get_kitchen_reviews(post_id):
    page = int(request.args.get('page', 1))
    per_page = int(request.args.get('per_page', 4))  
    pages_skip = (page - 1) * per_page #reviews-skip
    query = KitchenReview.query.filter_by(kitchen_id=post_id).order_by(desc(KitchenReview.nbr_of_stars))
    total_reviews = query.count()
    average_rating = Kitchen.query.filter_by(kitchen_id=post_id).first().avgrating() if Kitchen.query.filter_by(kitchen_id=post_id).first() else 0
    reviews = query.offset(pages_skip).limit(per_page).all()
    reviews_data = [
        {
            "author": {
                "id": review.user.user_id,
                "name": review.user.full_name,
                "pfp": review.user.pfp 
            },
            "id": review.kitchen_id,
            "rating": review.nbr_of_stars,
            "content": review.review_body
        }
        for review in reviews
    ]
    has_more = (pages_skip + per_page) < total_reviews
    return jsonify({
        "reviews": reviews_data,
        "has_more": has_more,
        "total_reviews": total_reviews,
        "average_rating": average_rating
    })


def get_kitchen_items(kitchen_id):
    page = int(request.args.get('page', 1))
    per_page = int(request.args.get('per_page', 10))

    kitchen = Kitchen.query.get_or_404(kitchen_id)
    items = Item.query.filter_by(kitchen_id=kitchen_id).order_by(desc(Item.post_date)).all()
    average_rating = kitchen.avgrating() if kitchen else 0
    start = (page - 1) * per_page
    end = start + per_page
    paginated_items = items[start:end]

    result = []
    for item in paginated_items:
        result.append({
            "item_id": item.item_id,
            "title": item.item_title,
            "description": item.item_description,
            "price": item.price,
            "rating" : {
                "value": item.avgrating(),
                "count": len(item.reviews)
            },
            "image_url": [image.image_link for image in item.gallery] if item.gallery else [],
            "category": {
                "id": item.item_category.cat_id,
                "name": item.item_category.cat_name
            },
            "delay": f"{(datetime.now().date() - item.post_date).days} days ago",
            "chef": {
                "name": item.kitchen.user.full_name,
                "profile_picture": item.kitchen.user.pfp,
                "location": {
                "wilaya": item.kitchen.user.address.wilaya,
                "baladiya": item.kitchen.user.address.baladiya
            },
            
            },
            "is_in_favorites": item in User.query.get(get_jwt_identity()).favorites if get_jwt_identity() else False,
        })

    return jsonify({
        "page": page,
        "per_page": per_page,
        "has_more": (end < len(items)),
        "total_items": len(items),
        "items": result,
        "average_rating": average_rating
    })
def write_kitchen_review(kitchen_id):
    user_id = get_jwt_identity()
    data = request.get_json()

    nbr_of_stars = data.get('nbr_of_stars')
    review_body = data.get('review_body')

    # Basic validation
    if nbr_of_stars is None or review_body is None:
        return jsonify({'error': 'Missing required fields'}), 400
    if float(nbr_of_stars) < 1 or float(nbr_of_stars) > 5:
        return jsonify({'error': 'Rating must be between 1 and 5'}), 400

    new_review = KitchenReview(
        user_id=user_id,
        kitchen_id=kitchen_id,
        nbr_of_stars=nbr_of_stars,
        review_body=review_body
    )

    db.session.add(new_review)
    db.session.commit()

    return jsonify({'message': 'Review submitted successfully'}), 201


"""def update_phone_numbers():
   
    try:
        # Get user ID from JWT token
        user_id = get_jwt_identity()
        
        # Get data from request
        data = request.get_json()
        phone_numbers = data.get('phone_numbers', [])
        
        # Delete all existing phone numbers for this user
        UserPhoneNumber.query.filter_by(user_id=user_id).delete()
        
        # Add new phone numbers
        for number in phone_numbers:
            if number and str(number).strip():  # Only add non-empty numbers
                new_phone = UserPhoneNumber(
                    user_id=user_id,
                    number=str(number).strip()
                )
                db.session.add(new_phone)
        
        # Commit the changes
        db.session.commit()
        
        # Return the updated phone numbers
        updated_numbers = UserPhoneNumber.query.filter_by(user_id=user_id).all()
        phone_list = [{'id': phone.phone_num_id, 'number': phone.number} for phone in updated_numbers]
        
        return jsonify({
            'message': 'Phone numbers updated successfully',
            'phone_numbers': phone_list
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'An error occurred: {str(e)}'}), 500"""


def update_phone_numbers():
    try:
        user_id = get_jwt_identity()
        data = request.get_json()

        print(f"Received data: {data}")
        if not isinstance(data, dict):
            return jsonify({'error': 'Bad JSON'}), 400

        phone_numbers = data.get('phone_numbers', [])
        print(f"Received phone numbers: {phone_numbers}")

        # Do nothing with DB
        return jsonify({'message': 'Test successful', 'phone_numbers': phone_numbers}), 200

    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'error': f'Exception: {str(e)}'}), 500
    
from datetime import datetime, timedelta
import os

import cloudinary
from routes import routes
from extensions import db, jwt , bcrypt , mail , oauth
from flask import current_app, redirect, jsonify, request, url_for, session
from flask_mail import Message
from flask_jwt_extended import (
    create_access_token,
    create_refresh_token,
    decode_token,
    jwt_required,
    get_jwt_identity,
    get_jwt,
    verify_jwt_in_request,
    set_access_cookies, 
    set_refresh_cookies
)
from itsdangerous import URLSafeTimedSerializer
from models import Address, Kitchen, User, UserPhoneNumber



# Serializer for password reset tokens
serializer = None  # placeholder for later

def init_serializer(secret_key):
    global serializer
    serializer = URLSafeTimedSerializer(secret_key)


# OAuth registration (Google example)
google = oauth.register(
    name='google',
    client_id=os.getenv('GOOGLE_CLIENT_ID'),
    client_secret=os.getenv('GOOGLE_CLIENT_SECRET'),
    access_token_url='https://accounts.google.com/o/oauth2/token',
    authorize_url='https://accounts.google.com/o/oauth2/auth',
    api_base_url='https://www.googleapis.com/oauth2/v1/',
    client_kwargs={'scope': 'openid email profile'}
)

# In-memory token blacklist
blacklisted_tokens = set()

@jwt.token_in_blocklist_loader
def check_if_token_in_blocklist(jwt_header, jwt_payload):
    return jwt_payload['jti'] in blacklisted_tokens

# Helper functions for password reset

def generate_reset_token(email):
    return serializer.dumps(email, salt='password-reset-salt')


def verify_reset_token(token, expiration=3600):
    try:
        email = serializer.loads(token, salt='password-reset-salt', max_age=expiration)
    except Exception:
        return None
    return email

# Routes

@routes.route('/api/v1/auth/login', methods=['POST'])
def login():

    data = request.get_json() or {}

    user = User.query.filter_by(email=data.get('email')).first()

    print("Searching for email:", data.get('email'))

    print("Found user:", user)

    print("Stored password hash:", user.password if user else None)
    print("Password provided:", data.get('password', ''))



    if not user or not bcrypt.check_password_hash(user.password, data.get('password', '')):
        return jsonify({'msg': 'Invalid credentials'}), 401
     

    # 🔐 Generate JWT Tokens
    try:
        access_token = create_access_token(
            identity=str(user.user_id),  # Keep as int, consistent with registration
            additional_claims={
                'email': user.email,
                'role': user.role,
                'full_name': user.full_name
            }
        )

        refresh_token = create_refresh_token(identity=str(user.user_id))
        
        response = jsonify({
            'msg': 'Login successful',
            'user': {
                'user_id': user.user_id,
                'full_name': user.full_name,
                'email': user.email,
                'role': user.role,
                'pfp': user.pfp
            },
            'tokens': {
                'access_token': access_token,
                'refresh_token': refresh_token
            }
        })
        
        return response, 200
    except Exception as e:
            return jsonify({'msg': 'Login failed during token generation', 'error': str(e)}), 500


@routes.route('/login/google')
def login_google():
    redirect_uri = url_for('google_callback', _external=True)
    return google.authorize_redirect(redirect_uri)

@routes.route('/login/google/callback')
def google_callback():
    token = google.authorize_access_token()
    userinfo = google.get('userinfo').json()
    email = userinfo.get('email')
    user = User.query.filter_by(email=email).first()
    if user:
        access_token = create_access_token(identity=str(user.user_id))
        refresh_token = create_refresh_token(identity=str(user.user_id))
        response = jsonify({'msg': 'Google login successful'})
        response.set_cookie('access_token', access_token, httponly=True, samesite='Strict')
        response.set_cookie('refresh_token', refresh_token, httponly=True, samesite='Strict')
        return response
    session['google_user'] = {
        'email': email,
        'name': userinfo.get('name'),
        'picture': userinfo.get('picture')
    }
    return redirect(url_for('complete_profile'))

@routes.route('/api/v1/auth/registration', methods=['POST'])
def registration():
    
    data = request.form.to_dict() or {}

    required = ['full_name', 'email', 'password', 'wilaya', 'baladiya', 'number']

    if not all(data.get(field) for field in required):
        return jsonify({'msg': 'Missing required fields'}), 400

    if User.query.filter(db.func.lower(User.email) == data['email'].lower()).first():
        return jsonify({'msg': 'Email already used Email already used Email already used Email already used'}), 400

    if UserPhoneNumber.query.filter_by(number=data['number']).first():
        return jsonify({'msg': 'Phone number already used'}), 400

    password_hash = bcrypt.generate_password_hash(data['password']).decode()
# 📸 Upload profile picture (pfp)
    pfp_url = None
    pfp_file = request.files.get('pfp')  # field name must be 'pfp' in the form
    
    if pfp_file:
        if not pfp_file.content_type.startswith('image/'):
            return jsonify({'msg': 'Profile picture must be an image'}), 400
        try:
            upload = cloudinary.uploader.upload(
                pfp_file,
                folder="users/pfp",
                public_id=f"{data['full_name'].replace(' ', '_')}_pfp",
                resource_type="image"
            )
            pfp_url = upload['secure_url']
        except Exception as e:
            return jsonify({'msg': 'Failed to upload profile image', 'error': str(e)}), 500
    else:
        # fallback default image
        pfp_url = "https://res.cloudinary.com/djplhhscl/image/upload/v1747937857/5873023072251004997_dltgsp.jpg"

    # 📍 Address
    location = Address.query.filter_by(baladiya=data['baladiya']).first()
    if not location:
        location = Address(wilaya=data['wilaya'], baladiya=data['baladiya'])
        db.session.add(location)

    # 👤 Create user
    new_user = User(
        full_name=data['full_name'],
        email=data['email'],
        password=password_hash,
        role='',  # temporarily empty until determined below
        pfp=pfp_url,
        address=location
    )
    db.session.add(new_user)
    db.session.flush()  # Assigns user_id

    # 📱 Phone
    phone = UserPhoneNumber(user=new_user, number=data['number'])
    db.session.add(phone)

    # 🧑 Role & Kitchen
    role = data.get('role', '').lower()
    if role == 'seller':
        # 📸 Upload cover picture (cvp)
        cvp_url = "https://res.cloudinary.com/YOUR_CLOUD_NAME/image/upload/v123456/default_cvp.png"
        cvp_file = request.files.get('cvp')
        if cvp_file:
            if not cvp_file.content_type.startswith('image/'):
                return jsonify({'msg': 'Cover picture must be an image'}), 400
            try:
                upload = cloudinary.uploader.upload(
                    cvp_file,
                    folder="kitchens/cvp",
                    public_id=f"{data['full_name'].replace(' ', '_')}_cvp",
                    resource_type="image"
                )
                cvp_url = upload['secure_url']
            except Exception as e:
                return jsonify({'msg': 'Failed to upload cover image', 'error': str(e)}), 500

        kitchen = Kitchen(
            kitchen_name=data.get('kitchen_name'),
            kitchen_bio=data.get('kitchen_bio'),
            user_id=new_user.user_id,
            cvp=cvp_url,
            avg_rating=0.0
        )
        new_user.role = 'Seller'
        db.session.add(kitchen)

    elif role == 'client':
        new_user.role = 'Client'
    else:
        return jsonify({"msg": "Wrong Role"}), 400
    
    db.session.commit() 

   # 🔐 Generate JWT Tokens
    try:
        # Create access and refresh tokens
        access_token = create_access_token(
            identity=str(new_user.user_id),
            additional_claims={
                'email': new_user.email,
                'role': new_user.role,
                'full_name': new_user.full_name
            }
        )
        
        refresh_token = create_refresh_token(identity=str(new_user.user_id))
        
        response = jsonify({
            'msg': 'Account created successfully',
            'user': {
                'user_id': new_user.user_id,
                'full_name': new_user.full_name,
                'email': new_user.email,
                'role': new_user.role,
                'pfp': new_user.pfp
            },
            'tokens': {
                'access_token': access_token,
                'refresh_token': refresh_token
            }
        })
        
        return response, 201
        
    except Exception as e:
        return jsonify({'msg': 'Account created but token generation failed', 'error': str(e)}), 500


@routes.route('/refresh', methods=['POST'])
@jwt_required(refresh=True)
def refresh():
    user_id = get_jwt_identity()
    access_token = create_access_token(identity=user_id)
    response = jsonify({
        'msg': 'Token refreshed',
        'access_token': access_token
    })
    return response

@routes.route('/logout', methods=['POST'])
@jwt_required()
def logout():
    jti = get_jwt()['jti']
    blacklisted_tokens.add(jti)
    # Get refresh token from Authorization header
    auth_header = request.headers.get('Authorization')
    if auth_header and auth_header.startswith('Bearer '):
        refresh_token = auth_header.split(' ')[1]
        try:
            decoded = decode_token(refresh_token)
            blacklisted_tokens.add(decoded['jti'])
        except Exception:
            pass
    return jsonify({'msg': 'Logged out'}), 200

# Password reset: request token and send email
@routes.route('/reset_password', methods=['POST'])
def request_password_reset():
    # Block if user already authenticated
    try:
        verify_jwt_in_request(optional=True)
        if get_jwt_identity():
            return jsonify({'msg': 'Already authenticated', 'redirect': '/home'}), 400
    except Exception:
        pass
    # request reset token and send email
    data = request.get_json() or {}
    email = data.get('email')
    user = User.query.filter_by(email=email).first()
    if not user:
        return jsonify({'msg': 'User not found'}), 404
    data = request.get_json() or {}
    email = data.get('email')
    user = User.query.filter_by(email=email).first()
    if not user:
        return jsonify({'msg': 'User not found'}), 404
    token = generate_reset_token(email)
    reset_url = url_for('reset_with_token', token=token, _external=True)
    msg = Message(
        subject='Password Reset Request',
        sender=os.getenv('MAIL_USERNAME'),
        recipients=[email]
    )
    msg.body = f'Click the link to reset your password: {reset_url}'
    mail.send(msg)
    return jsonify({'msg': 'Password reset email sent'}), 200


@routes.route('/reset_password/<token>', methods=['POST'])
def reset_with_token(token):
    # Block if user already authenticated
    try:
        verify_jwt_in_request(optional=True)
        if get_jwt_identity():
            return jsonify({'msg': 'Already authenticated', 'redirect': '/home'}), 400
    except Exception:
        pass
    # verify token and reset password
    data = request.get_json() or {}
    new_password = data.get('password')
    email = verify_reset_token(token)
    if not email:
        return jsonify({'msg': 'Invalid or expired token'}), 400
    user = User.query.filter_by(email=email).first()
    if not user:
        return jsonify({'msg': 'User not found'}), 404
    user.password = bcrypt.generate_password_hash(new_password).decode()
    db.session.commit()
    return jsonify({'msg': 'Password has been reset'}), 200



@routes.route("/api/test_authentacation", methods=["POST"])
@jwt_required()
def test_auth():
    id_from_jwt = get_jwt_identity()
    claims = get_jwt()

    email_from_jwt = claims.get("email")
    role_from_jwt = claims.get("role")

    # Validate the ID format
    try:
        id_from_jwt = int(id_from_jwt)
    except ValueError:
        return jsonify({"checking result": "False", "reason": "Invalid user ID format"}), 400

    # Fetch user from DB
    user = User.query.get(id_from_jwt)
    if not user:
        return jsonify({"checking result": "False", "reason": "User not found in DB"}), 404

    # Compare DB fields with token claims
    if user.email != email_from_jwt:
        return jsonify({"checking result": "False", "reason": "Email mismatch"}), 401

    if user.role != role_from_jwt:
        return jsonify({"checking result": "False", "reason": "Role mismatch"}), 401

    # Don't require password if frontend doesn't send it
    return jsonify({
        "result": "True",
        "message": "Token matches database user",
        "user": {
            "id": user.user_id,
            "email": user.email,
            "role": user.role
        }
    }), 200

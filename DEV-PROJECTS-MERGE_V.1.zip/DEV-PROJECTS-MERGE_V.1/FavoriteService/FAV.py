from urllib.parse import urlparse
from extensions import db
from models import *
from flask import jsonify, redirect , request, url_for
from flask_jwt_extended import get_jwt_identity 
from sqlalchemy.orm import joinedload
from datetime import datetime

def Add_Favorites():
    
    user = get_jwt_identity()

    # Parse JSON data
    data = request.get_json()

    # Handle missing or invalid item_id
    if not data or 'Item_id' not in data:
        return jsonify({'error': 'Missing Item_id'}), 400

    # Check if the favorite already exists (prevent duplicates)
    existing_favorite = Favorite.query.filter_by(user_id=user, item_id=data['Item_id']).first()
    if existing_favorite:
        return jsonify({'error': 'Item already in favorites'}), 400

    # Create new favorite record
    favorite = Favorite(
        user_id=user,
        item_id=data['Item_id']
    )

    # Add and commit to the database
    db.session.add(favorite)
    db.session.commit()

    # Return success message
    return jsonify({'operation_status': 'Success', 'message': 'Item added to favorites'}), 200


def Remove_Favorite():
    
    user = get_jwt_identity()
    

    # Parse JSON data
    data = request.get_json()

    # Handle missing or invalid item_id
    if not data or 'Item_id' not in data:
        return jsonify({'error': 'Missing Item_id'}), 400

    # Find the favorite record to delete
    favorite_to_remove = Favorite.query.filter_by(user_id=user, item_id=data['Item_id']).first()
    
    if not favorite_to_remove:
        return jsonify({'error': 'Item not found in favorites'}), 404

    # Delete the favorite
    db.session.delete(favorite_to_remove)
    db.session.commit()

    # Return success message
    return jsonify({'operation_status': 'Success', 'message': 'Item removed from favorites'}), 200


def Get_Favorites():
    user = get_jwt_identity()
     
    user_id = user
    
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 10, type=int)

    pagination = Favorite.query.filter_by(user_id=user_id) \
        .options(joinedload(Favorite.item)) \
        .paginate(page=page, per_page=per_page, error_out=False)

    favorites = pagination.items
    results = []
    for favorite in favorites:
        item = favorite.item
        if item:
            results.append({
                'item_id': item.item_id,
                'title': item.item_title,
                'price': item.price,
                'image': item.gallery[0].image_link if item.gallery else None,
                'description': item.item_description,
                'average_rating': item.avgrating(),
                'is_in_favorites': item in User.query.get(user_id).favorites if user_id else False,
                'delay': f"{(datetime.now().date() - item.post_date).days} days ago",
                'category': {
                    'id': item.item_category.cat_id if item.item_category else None,
                    'name': item.item_category.cat_name if item.item_category else None
                },
                'chef': {
                    'name': item.kitchen.user.full_name,
                    'kitchen_id': item.kitchen.kitchen_id,
                    'profile_picture': item.kitchen.user.pfp,
                    'location': {
                        'wilaya': item.kitchen.user.address.wilaya,
                        'baladiya': item.kitchen.user.address.baladiya
                    }
                }
            })
    return jsonify({
        'operation_status': 'Success',
        'favorites': results,
        'total_pages': pagination.pages,
        'current_page': pagination.page,
        'total_items': pagination.total,
        'has_more': len(results) == per_page
    }), 200


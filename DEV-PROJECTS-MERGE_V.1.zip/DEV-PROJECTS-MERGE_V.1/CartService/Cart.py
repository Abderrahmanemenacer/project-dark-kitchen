from extensions import db
from models import Cart, Order , CartItem, User
from flask_jwt_extended import get_jwt_identity
from flask import jsonify, request, url_for


def ADD_to_CART():

    user = get_jwt_identity()


    try:
        user_id = int(user)
    except (ValueError, TypeError):
        return jsonify({"message": "Invalid user identity"}), 401

    # Check if user exists in DB before creating cart
    user_obj = User.query.filter_by(user_id=user_id).first()
    if not user_obj:
        return jsonify({"message": "User not found"}), 404

    data = request.get_json()
    if not data or 'item_id' not in data or 'quantity' not in data:
        return jsonify({"message": "Missing 'item_id' or 'quantity' in request"}), 400

    cart = Cart.query.filter_by(user_id=user_id).first()

    if not cart:
        cart = Cart(user_id=user_id)
        db.session.add(cart)
        db.session.commit()

    db.session.flush()
    existing_cart_item = CartItem.query.filter_by(cart_id=cart.cart_id, item_id=data['item_id']).first()

    if existing_cart_item:
        existing_cart_item.quantity += data['quantity']
    else:
        new_cart_item = CartItem(
            cart_id=cart.cart_id,
            item_id=data['item_id'],
            quantity=data['quantity'],
        )
        db.session.add(new_cart_item)

    db.session.commit()

    return jsonify({"status": "success"}), 200



def Delete_item_from_cart():
    # Get the logged-in user identity
    user = get_jwt_identity()

    # Parse the JSON body
    data = request.get_json()
    if not data or 'item_id' not in data:
        return jsonify({"message": "Missing 'item_id' in request body"}), 400

    item_id = data['item_id']

    # Find the user's cart
    cart = Cart.query.filter_by(user_id=user).first()
    if not cart:
        return jsonify({"message": "Cart not found for this user."}), 404

    # Find the item in the cart
    cart_item = CartItem.query.filter_by(cart_id=cart.cart_id, item_id=item_id).first()
    if not cart_item:
        return jsonify({"message": "Item not found in cart."}), 404

    # Delete the item
    db.session.delete(cart_item)
    db.session.commit()

    return jsonify({"message": "Item successfully deleted from cart."}), 200





def edit_quantity_AND_note_in_cart():
    user = get_jwt_identity()

    # Parse data from the request
    data = request.get_json()

    item_id = data.get('item_id')
    quantity = data.get('quantity')
    new_note = data.get('new_note')

    # Validate input data
    if not item_id or not quantity:
        return jsonify({"message": "Missing 'item_id' or 'quantity'."}), 400

    # Find the user's cart
    cart = Cart.query.filter_by(user_id=user).first()
    if not cart:
        return jsonify({"message": "Cart not found."}), 404

    # Find the CartItem entry
    item_to_update = CartItem.query.filter_by(cart_id=cart.cart_id, item_id=item_id).first()
    if not item_to_update:
        return jsonify({"message": "Item not found in cart."}), 404

    # Update the quantity and note
    item_to_update.quantity = quantity
    # CartItem.Note = new_note  # Update order note

    db.session.commit()  # Commit the changes

    return jsonify({"message": "Item quantity and order note updated successfully."}), 200



def GET_ALL_CartItems():
    user_id = get_jwt_identity()
    
    # Get pagination parameters from query parameters
    page = request.args.get('page', default=1, type=int)
    per_page = request.args.get('per_page', default=10, type=int)

    # Query with pagination
    paginated_items = CartItem.query \
        .join(Cart) \
        .filter(Cart.user_id == user_id) \
        .paginate(page=page, per_page=per_page, error_out=False)

    cart_items_list = []

    for cart_item in paginated_items:
        item = cart_item.item
        cart_item_data = {
            "cart_item_id": cart_item.cart_item_id,
            "item_name": item.item_title,  # Correct field name
            "quantity": cart_item.quantity,
            "price": item.price,
            "total_price": item.price * cart_item.quantity
        }
        cart_items_list.append(cart_item_data)

    return jsonify({
        "message": "Cart items fetched successfully",
        "cart_items": cart_items_list,
        "total": paginated_items.total,
        "pages": paginated_items.pages,
        "current_page": paginated_items.page,
        "per_page": paginated_items.per_page
    }), 200
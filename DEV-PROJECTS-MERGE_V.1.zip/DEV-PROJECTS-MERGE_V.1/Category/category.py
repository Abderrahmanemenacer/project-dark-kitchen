from models import Category , Item
from flask import jsonify, request
from datetime import datetime


def get_all_categories():

    category = Category.query.all()
    results = []

    for cat in category:
        result = {
            "Category_id": cat.cat_id,
            "Category_name": cat.cat_name,
            "number_of_items": len(cat.items)
        }
        results.append(result)

    return jsonify(results)


def get_all_items_of_a_category(category_id):
    
    page = int(request.args.get('page', 1))
    per_page = int(request.args.get('per_page', 10))
    items= Item.query.filter_by(cat_id=category_id).all()
    if not items:
        return jsonify({"message": "No items found for this category"}), 404   
    paginated_items = items[(page - 1) * per_page: page * per_page]
    result = []
    for item in paginated_items:
        item_data = {
            "item_id": item.item_id,
            "title": item.item_title,
            "chef": {
                "location": f"{item.kitchen.user.address.wilaya}, {item.kitchen.user.address.baladiya}",
                "name": item.kitchen.kitchen_name,
                "profile_picture": item.kitchen.user.pfp if item.kitchen.user.pfp else None
            },
            "image_url": item.gallery[0].image_link if item.gallery else None,
            "description": item.item_description,
            "delay": f"{(datetime.now().date() - item.post_date).days} days ago",
            "price": item.price,
            "avg_rating": item.avgrating(),
            "category": {
                "id": item.item_category.cat_id,
                "name": item.item_category.cat_name
            },
        }
        result.append(item_data)

    return jsonify({
        "items": result,
        "total_items": len(items),
        "page": page,
        "per_page": per_page
    }), 200
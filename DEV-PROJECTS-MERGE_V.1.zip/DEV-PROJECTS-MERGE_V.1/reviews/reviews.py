from flask_jwt_extended import get_jwt_identity
from models import ItemReview ,Item
from flask import jsonify , request
from extensions import db


def get_post_review(post_id):

    revs = ItemReview.query.filter_by(item_id= post_id).all()
    
    return jsonify({
        f"rev{i+1}": {
            "user_id": d.user_id,
            "item_id": d.item_id,
            "review_body": d.review_body,
            "nbr_of_stars": d.nbr_of_stars
        } for i, d in enumerate(revs)
    })


"""def calculate_avg_of_post_rev(post_id):
    
    revs = ItemReview.query.filter_by(item_id= post_id).all()
    
    total_revs = len(revs)
    if total_revs ==  0 :
        return 0
    
    total_stars = sum(r.nbr_of_stars for r in revs)

    avg_rev = total_stars/total_revs

    item = Item.query.filter_by(item_id = post_id).first()

    if not item :
        return jsonify({"Status" : "Error"}) , 400
    
    item.avg_rating = avg_rev

    db.session.commit()

    return jsonify({"Status" : "Success"}) , 200"""


def commenting_on_post(user):

    Data = request.get_json()
    if not Data["Item"] :
        return jsonify({"ERROR" : "NO ITEM HAS BEEN SENT"}) , 400
    
    comment = ItemReview(
        user_id = user,
        item_id = Data["Item"],
        review_body = Data["String"],
        nbr_of_stars = Data["Stars"]
    )
    db.session.add(comment)
    db.session.commit()

    return jsonify({"status": "success"}), 200

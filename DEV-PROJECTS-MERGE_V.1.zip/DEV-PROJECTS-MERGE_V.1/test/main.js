let url = 'https://dev-projects-4t39.onrender.com/api/v1/auth/registration';


// let form = new FormData();
// form.append('full_name', 'ismail');
// form.append('email', 'sms2msmsd@gmail.com');
// form.append('password', 'Smail@123');
// form.append('wilaya', 'blida');
// form.append('baladiya', 'blida');
// form.append('number', '03334555');
// form.append('role', 'Client'); // required by backend

document.querySelector('button').addEventListener('click', (e)=>{
    
    // axios.post(url, form ,{
    //   withCredentials: true
    // })
    // .then(response => {
    // console.log('Success:', response.data);
    // })
    // .catch(error => {
    // console.error('Axios error:', error);
    // });

    // axios.get('https://dev-projects-4t39.onrender.com/api/post/3' ,{
    //    withCredentials: true
    //  } ).then(res =>{
    //     console.log(res) ; 
    // })

    let url = 'https://dev-projects-4t39.onrender.com/api/v1/auth/login'
    let info = { 
        email : "smail@example.com" ,
        password :'Smail@123' 
    } ; 

    axios.post(url ,info ,  {
       withCredentials: true
     }).then(res=>{
        console.log(res.data) ;
     }).catch(e=>console.log(e))
})

//   const cookies = document.cookie.split(";");

//   for (let cookie of cookies) {
//     const eqPos = cookie.indexOf("=");
//     const name = eqPos > -1 ? cookie.substring(0, eqPos).trim() : cookie.trim();

//     // Expire the cookie
//     document.cookie = ${name}=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/;
//   }

 

// let url = "https://dev-projects-4t39.onrender.com/api/post/3"
// axios.post(url , {
//     email : "alice.sm0101010000075701ith@example.com" , 
//     password : 'MyPass#2025'

// } ,{
//      withCredentials: true
// })
// .then(response => {
//   console.log('Success:', response.data);
// })
// .catch(error => {
//   console.error('Axios error:', error);
// })
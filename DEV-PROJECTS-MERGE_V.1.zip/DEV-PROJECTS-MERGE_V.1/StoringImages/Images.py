from cloudinary import CloudinaryImage
import cloudinary
import cloudinary.uploader
import cloudinary.api
from flask import request
from extensions import db


def profileimage():
    file = request.files()
    
    url = upload_file()
    
    return

def upload_file(file):
    """
    Upload a file (from request.files) to Cloudinary.
    Returns the upload result dict.
    """
    if not file:
        raise ValueError("No file provided for upload")
    result = cloudinary.uploader.upload(file)
    return result


def delete_file(public_id):
    """
    Delete an uploaded file on Cloudinary by public_id.
    Returns the delete result dict.
    """
    if not public_id:
        raise ValueError("No public_id provided for deletion")
    result = cloudinary.uploader.destroy(public_id)
    return result


def generate_url(public_id, width=None, height=None, crop=None):
    """
    Generate a Cloudinary URL for an uploaded asset with optional transformations.
    Returns the generated URL string.
    """
    if not public_id:
        raise ValueError("No public_id provided for URL generation")
    url, _options = cloudinary.utils.cloudinary_url(
        public_id,
        width=width,
        height=height,
        crop=crop
    )
    return url


def generate_url_obj(public_id, width=None, height=None, crop=None):
    """
    Alternative way to generate a Cloudinary URL using CloudinaryImage object.
    Returns the URL string.
    """
    if not public_id:
        raise ValueError("No public_id provided for URL generation")
    img = CloudinaryImage(public_id)
    url = img.build_url(width=width, height=height, crop=crop)
    return url


def list_resources(prefix=None, max_results=10):
    """
    List uploaded resources, optionally filtered by prefix.
    Returns a dict with resources info.
    """
    resources = cloudinary.api.resources(
        type='upload',
        prefix=prefix,
        max_results=max_results
    )
    return resources


def get_resource(public_id):
    """
    Get detailed metadata about a single uploaded resource.
    Returns the resource info dict.
    """
    if not public_id:
        raise ValueError("No public_id provided for resource info")
    resource = cloudinary.api.resource(public_id)
    return resource